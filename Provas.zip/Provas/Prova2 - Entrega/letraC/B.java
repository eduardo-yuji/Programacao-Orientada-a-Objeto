/*
Autor:  Sefora Davanso de Assis
RA: 2367777
*/
package letraC;


public abstract class B implements IC {
    @Override
    public abstract int b1();
    @Override
    public abstract int b2( );  
    @Override
    public abstract int b3( );      
}
