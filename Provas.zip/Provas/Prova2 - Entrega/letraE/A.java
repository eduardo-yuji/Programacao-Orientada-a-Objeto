/*
Autor:  Sefora Davanso de Assis
RA: 2367777
*/
package letraE;


public abstract class A extends B {
    public abstract int a1( );
    public abstract int a2( );  
}
