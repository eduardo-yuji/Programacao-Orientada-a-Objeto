/*
Autor:  Sefora Davanso de Assis
RA: 2367777
*/
package letraD;

public abstract class A extends B {
    public abstract int a1( );
    public abstract int a2( );  

    public int b1(){};
    public  int b2( ){};  
    public  int b3( ){}; 
}
