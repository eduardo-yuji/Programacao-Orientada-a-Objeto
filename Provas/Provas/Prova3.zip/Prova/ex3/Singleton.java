
package ex3;

import javax.swing.JOptionPane;


public class Singleton {
    private static Singleton s;
    private static String conteudo1;
    private static String conteudo2;

    public static Singleton iniciar() {
         JOptionPane.showMessageDialog(null, conteudo1+" "+conteudo2,
                "JFrame", JOptionPane.INFORMATION_MESSAGE);
        return null;
    }

    public String imprimirConteudo() {
       return conteudo1+conteudo2;
    }

    public static void setConteudo1(String conteudo1) {
            s.conteudo1 = conteudo1;
    }

    public static void setConteudo2(String conteudo2) {
            s.conteudo2 = conteudo2;
    }
}

