/*
 * Nome : Séfora Davanso de Assis 
 * Ra : 236777
 * Exercicio 3
 */
package ex3;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Principal extends JFrame {

    private JLabel rotulo;
    private JLabel rotulo1;
    private JTextField campoTexto;
    private JTextField campoTexto1;
    private JRadioButton r1, r2;
    private ButtonGroup grupo;
    private JTextArea textoArea;
    private JButton botao;
               
    public Principal(){
     
        setLayout(new FlowLayout());
               
        rotulo = new JLabel("Nome");
        campoTexto = new JTextField(10);
        rotulo1 = new JLabel("Endereco");
        campoTexto1 = new JTextField(10);
        r1 = new JRadioButton("(3)");
        r2 = new JRadioButton("(4)");
        grupo = new ButtonGroup();
        textoArea = new JTextArea("(6)",10,10);
        botao = new JButton("(5)");
                    
        
        campoTexto.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent objetoEvento){
               System.out.println(objetoEvento.getActionCommand());
               Singleton.setConteudo1(objetoEvento.getActionCommand());
               JOptionPane.showMessageDialog(null, 
                       objetoEvento.getActionCommand());
           } 
        });
        
        campoTexto1.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent objetoEvento){
               System.out.println(objetoEvento.getActionCommand());
               Singleton.setConteudo2(objetoEvento.getActionCommand());
               JOptionPane.showMessageDialog(null, 
                       objetoEvento.getActionCommand());
           }
        });
        
        botao.addActionListener( new ActionListener(){ //Classe Interna Anonima	
                    public void actionPerformed(ActionEvent e){
                        Singleton.iniciar();
                    }
                });	
        
        grupo.add(r1);
        grupo.add(r2);
        
        add(rotulo);
        add(campoTexto);
        add(rotulo1);
        add(campoTexto1);
        add(r1);
        add(r2);
        add(textoArea);
        add(botao);
        
    }    

    public static void main(String[] args) {
        Principal principal = new Principal();
        principal.setDefaultCloseOperation(EXIT_ON_CLOSE);
        principal.setSize(200,300);
        principal.setVisible(true);
    }
    
}

