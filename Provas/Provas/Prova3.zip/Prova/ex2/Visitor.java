
package ex2;

import javax.swing.JOptionPane;

public class Visitor {
    private static Visitor v;

    private static String conteudo1;
    private static String conteudo2;

    public static String getConteudo1() {
        return conteudo1;
    }

    public static String getConteudo2() {
        return conteudo1;
    }
    
    public static void setConteudo1(String conteudo1) {
            v.conteudo1 = conteudo1;
    }

    public static void setConteudo2(String conteudo2) {
            v.conteudo2 = conteudo2;
    }
}
